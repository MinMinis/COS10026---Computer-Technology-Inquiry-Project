<?php
	$host = "feenix-mariadb.swin.edu.au";
    $user = "s104169675";
    $pwd = "180704";
    $sql_db = "s104169675_db";
	$login_tb = "managers";
    $order_tb = "orders";
?>
	
	
	