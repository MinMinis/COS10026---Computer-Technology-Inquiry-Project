<?php
	$host = "feenix-mariadb.swin.edu.au";
	$user = "s103809048"; // your user name
	$pwd = "se7en"; // your password (date of birth ddmmyy unless changed)
	$sql_db = "s103809048_db"; // your database
?>
	
	
	